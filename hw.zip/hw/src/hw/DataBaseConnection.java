package hw;

import java.sql.Connection;

public interface DataBaseConnection {
	public Connection getDataBaseConnection();
	}
