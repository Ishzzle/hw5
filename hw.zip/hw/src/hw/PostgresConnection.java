package hw;

import java.sql.Connection;

public class PostgresConnection implements DataBaseConnection {
		public Connection getDataBaseConnection() {
			Connection conn = null;
			return conn;
			
		}
	}

